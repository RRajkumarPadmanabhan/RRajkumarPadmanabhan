<?php
session_start();
header("location:policelogin.php");
session_destroy();
?>